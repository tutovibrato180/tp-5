using System.Timers;
using System;

/// <summary>
/// The scheduler
/// </summary>
public class Scheduler : ITimeTickReceiver
{
    private CPU currentCPU;
    private CircularProcesList queue;
    private long timeSlice;
    private long timeSliceCounter;
    private const int DEFAULT_TIME_SLICE = 2000; // default timeslice is 2 seconds
    private long clock=0; // the current time in this simulator

    //private TestProcess tps;


    //
    private static long[] tabOfInitialCPUTimeNeeded = new long[] { 0, 0, 0 };
    private static long[] tabOfWaitingTime = new long[] { 0, 0, 0 };
    private static long[] tabOfProcesses = new long[] { 1, 2, 3 };
    private static long[] tabOfTurnAroundTime = new long[] { 0, 0, 0 };
    private static long[] tabOfLastTime = new long[] { 0, 0, 0 };
    private static long[] tabOfFirstTime = new long[] { 0, 0, 0 };
    private static String[] tabOfFirstNameProcesses = new String[] { "", "", "" };
    private static String[] tabOfLastNameProcesses = new String[] { "", "", "" };
    private static int cpt = 0;
    private static int firstnumber = 0;
    private static int lastnumber = 0;

    public Scheduler(CPU cpu )
    {
        this.currentCPU = cpu;
        //this.timeSlice = timeSlice;
        this.timeSlice = DEFAULT_TIME_SLICE;
        this.timeSliceCounter = 0;
        queue = new CircularProcesList();
        cpu.Scheduler = this;        

    }
    
    public Scheduler(CPU cpu, int quantum)
        : this(cpu)
    {
        this.timeSlice = quantum;
    }

    public long TimeSlice
    {
        get
        {
            return timeSlice;
        }
        set
        {
            this.timeSlice = value;
        }
    }

    /// <summary> 
    /// The average turnaround time of all processes that finished up to now
    /// </summary>
    public bool NoProcesses
    {
        get
        {
            lock (this)
            {                
                return queue.Empty && !currentCPU.Busy;
            }
        }
    }

    /// <summary> 
    /// Introduces a new TestProcess that must be execeuted on the CPU
    /// </summary>
    /// <param name="t">The new TestProcess</param>
    public void AddProcess(IProcess t)
    {
        queue.AddItem(t);
        t.StartTime = clock;
        tabOfInitialCPUTimeNeeded[cpt] = t.InitialCPUTimeNeeded;
        //System.Console.WriteLine(t.ToString());
        cpt = cpt + 1;
    }


    // Another Method to find the waiting time
    // for all processes

    public static void AnotherfindTurnAroundTimeAndWaitingTime()
    {

        TestProcess t = new TestProcess("tempo", 0);
        for (int i = 0; i < 3; i++)
        {
            for(int j = 0; j < 3; j++)
            {
                if(tabOfFirstNameProcesses[i] == tabOfLastNameProcesses[j])
                {
                    //Console.WriteLine(tabOfFirstNameProcesses[i] +"=="+ tabOfLastNameProcesses[j]);
                    //
                    t.Bt = tabOfLastTime[j];
                    t.Rem_bt = tabOfFirstTime[i];
                    tabOfTurnAroundTime[i] = t.TurnAroundTime;
                    //
                    t.Rem_bt = tabOfTurnAroundTime[i];
                    t.Bt = tabOfInitialCPUTimeNeeded[i];                    
                    tabOfWaitingTime[i] = t.WaitingTime;
                }
            }
            
            
        }


    }

    // Function calculate average time

    public static void findavgtime()
    {
        long total_wt = 0;
        long total_tat = 0;
        AnotherfindTurnAroundTimeAndWaitingTime();
        for(int i = 0; i < cpt; i++)
        {
            total_wt = total_wt + tabOfWaitingTime[i];
            total_tat = total_tat + tabOfTurnAroundTime[i];
        }


        // Show Menu
        Console.WriteLine(" Processes\t\t InitialCPUTimeNeeded\t\t Waiting Time\t\t\t TurnAroundTime");
        for (int i = 0; i < cpt; i++)
        {
            Console.WriteLine(tabOfProcesses[i] + "\t\t\t\t" + tabOfInitialCPUTimeNeeded[i] + "\t\t\t\t" + tabOfWaitingTime[i] + "\t\t\t\t" + tabOfTurnAroundTime[i]);
        }


        // Average turn around time
        Console.WriteLine("Average Turn Around Time \t" + (float)total_tat / (float)cpt);
        // Average waiting time
        Console.WriteLine("Average Waiting Time \t" + (float)total_wt/(float)cpt);
        
    }


    /// <summary> 
    /// Signal to the scheduler that scheduling is needed in the next timertick
    /// </summary>
    public void schedulingNeeded()
    {
        this.timeSliceCounter = 0;
    }

    /// <summary>
    /// This method is called when a timertick occurs
    /// Receive ticks until time quantum has finished, then schedule new proces
    /// </summary>
    /// <param name="source"></param>
    /// <param name="e"></param>
    public void ReceiveTimeTick(object source, ElapsedEventArgs e)
    {
        this.clock = ((HardwareTimer)source).Clock;
        this.timeSliceCounter--;
        if (this.timeSliceCounter <= 0)
        {
            // Time slice has finished, there for reschedule
            this.schedule();
            this.timeSliceCounter = this.timeSlice / 100;
        }
    }

    /// <summary> 
    /// The actual scheduling operation For Round Robin
    /// </summary>
    public void schedule()
    {
        lock (this)
        {
            System.Console.Out.WriteLine(clock + "\t* * * Context Switch * * * ");
            IProcess current;

            // remove process from CPU and put in queue
            IProcess removedProcess = this.currentCPU.RemoveProcess();
            if (removedProcess != null)
            {
                System.Console.Out.WriteLine(clock + "\tremoving from CPU " + removedProcess.Name);
                
                // Receiver about the First time of process in the CPU
                // and the name of process
                if (firstnumber < 3)
                {
                    tabOfFirstTime[firstnumber] = clock - TimeSlice;
                    tabOfFirstNameProcesses[firstnumber] = removedProcess.Name;
                    firstnumber = firstnumber + 1;
                }
                // add to queue if not ready
                if (!removedProcess.Ready)
                {
                    System.Console.Out.WriteLine(clock + "\tadding to queue " + removedProcess.Name);
                    this.queue.AddItem(removedProcess);
                }
                else
                {
                    // Receiver about the Last time of process in the CPU
                    // and the name of process
                    
                    System.Console.Out.WriteLine(clock + "\tFINISHED: " + removedProcess.Name);

                    if (lastnumber < 3)
                    {
                        tabOfLastTime[lastnumber] = clock;
                        tabOfLastNameProcesses[lastnumber] = removedProcess.Name;
                        lastnumber = lastnumber + 1;
                    }
                
                }
            }

            // select new process for CPU
            current = queue.Next;

            // end of scheduling algorithm
            
            // start the selected process on the CPU (if any)
            if (current != null)
            {              
                System.Console.Out.WriteLine(clock + "\tputting on CPU " + current.Name);
                this.currentCPU.SetProcess(current);
                //System.Console.Out.WriteLine("\n"+current.Name+" Brust Time :"+current.InitialCPUTimeNeeded);
                //TimeSlice = current.InitialCPUTimeNeeded;                
            }
            // no current processes
            else
            {
                System.Console.Out.WriteLine(clock + "\tqueue empty");                
            }
        }
    }
}